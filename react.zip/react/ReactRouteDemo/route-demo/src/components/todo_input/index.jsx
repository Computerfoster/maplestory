import React, { Component } from 'react';

class index extends Component {
    constructor(props){
        super(props)
        this.state={
            value:''
        }
    }
    handleInputChange=(e)=>{
        this.setState({
            value:e.target.value
        })
    }
    handleAdd=()=>{
        let text=this.state.value
        if(text.trim()){
            this.props.handleAdd(text)
            
            this.setState({
                value:''
            })
        }
    }
    render() {
        return (
            <div>
                <input onChange={(e)=>{this.handleInputChange(e)}}></input>
                <button onClick={()=>{this.handleAdd()}}>submit</button>
            </div>
        );
    }
}

export default index;