import {addCount} from '../redux/actions_Couter'
export function asyncAdd(){
    return (dispatch,state)=>{
        dispatch(addCount)
        console.log('fetching begin')
        fetch('api/page3',{
            method:"GET",
            headers:{
                'Content-Type':'application/json',
            }
        })
            .then(res=>{
                if(!res.ok){
                    throw new Error('fail')
                }
                res.json().then(res=>{
                    console.log('fetch well')
                    console.log(JSON.stringify(res))
                    console.log('fetch over')
                })
            }).catch(err=>{
                console.log('fetch bad')
            })
    }
}