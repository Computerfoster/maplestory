import React from 'react'
import PropTypes from 'prop-types'

export default class Ca extends React.Component{
    static contextTypes={
        color:PropTypes.string
    }
    static propTypes={
        value:PropTypes.string
    }
    render(){
        const {value}=this.props
        return (
            // 在此就可以获取context中的属性（color）内容
            <li style={{backgroundColor:this.context.color}}>
                <span>{value}</span>
            </li>
        )
    }
}