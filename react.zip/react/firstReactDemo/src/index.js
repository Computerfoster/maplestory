import React from 'react' //创建组件，虚拟dom元素
import ReactDom from 'react-dom'//展示组件及虚拟dom
// import Hello from './components/funComponent_1'
// import ClassCom2 from './components/classComponent_1'
// import Cmt from './components/cmtList'
// import Binde from '@/components/bindEvent'
// import BindState from '@/components/bindEventState'
// import Chlid from '@/components/propType'
// import Cfather from '@/components/comConnect_father'
// import Cc from '@/components/comCon_C'
// import BindThis from '@/components/BindThis'
// 引入redux，创建一个全局唯一的store
import {createStore} from 'redux'
// 引入reducer
import counter from './reducers/index.js'
// 引入使用的redux的组件
import Counter from './components/Counter.jsx'
import Mapdemo from './components/Mapdemo'

const store=createStore(counter)

const render=()=>ReactDom.render(<div> 
    {/* 123 */}
    {/*直接把组件的名称以标签的形式丢到页面即可*/}
    {/*<Hello {name={dog.name} age={dog.age} gender={dog.gender}}></Hello>*/}
    {/*<Hello {...dog}></Hello>*/}
    {/* <ClassCom2 name={dog.name} age={dog.age}></ClassCom2> */}
    {/* <Cmt></Cmt> */}
    {/* <Binde></Binde> */}
    {/* <BindState></BindState> */}
    {/* <Chlid name='jack'></Chlid> */}
    {/* <Cfather></Cfather> */}
    {/* <Cc></Cc> */}
    {/* <BindThis></BindThis> */}
    {/* <Counter 
        // 将state的值作为props参数传给组件
        value={store.getState()}
        // 为组件传递两个函数参数，当触发这个参数时，就dispatch发起一个action供reducer处理
        onIncrement={()=>store.dispatch({type:'INCREMENT'})}
        onDecrement={()=>store.dispatch({type:'DECREMENT'})}
    >    
    </Counter> */}
    <Mapdemo></Mapdemo>
</div>,document.getElementById('app')) 

// 渲染组件
render()
// 为store设置监听函数，一旦state发生改变，就自动执行view的更新函数即render函数
store.subscribe(render)