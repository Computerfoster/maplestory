import React from 'react' //创建组件，虚拟dom元素

// 第一种创建组件的方式（构造函数）首字母必须是大写（react根据这个来判断其是否是一个组件）；叫做无状态组件
export default function Hello(props) {
    // 若return一个null表示此组件什么都不渲染
    //（必须return一个值）即JSX语法的虚拟DOM
    // props为组件传递的参数（只读不可修改）
    console.log(props)
    return <h1>这是第一个组件:--{props.name}--{props.age}--{props.gender}</h1>
}
