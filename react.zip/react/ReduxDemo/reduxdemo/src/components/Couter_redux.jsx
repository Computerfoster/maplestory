import React from 'react'
import {connect} from 'react-redux'
import {addCount} from '../redux/actions_Couter'
import {subCount} from '../redux/actions_Couter'
import {asyncAdd} from '../redux/actions_Async'

class CounterApp extends React.Component {
    render() {
        const {count,add,sub,asyncAdd}=this.props
        return (
            <div>
                <span>this count is {count}</span>{' '}{' '}
                <button onClick={add}>ADD</button>{' '}
                <button onClick={sub}>SUB</button>{' '}
                <button onClick={asyncAdd}>ASYNC</button>{' '}
            </div>
        );
    }   
}

const mapStateToProps=state=>({
    count:state.countReducer
})
// 将 store 中的action作为 props 绑定到组件上。
const mapDispatcherToProps=dispatch=>({
    // 应当都写成函数，方便onClick事件
    add:()=>dispatch(addCount),
    sub:()=>dispatch(subCount),
    asyncAdd:()=>dispatch(asyncAdd())
})

export default connect(mapStateToProps,mapDispatcherToProps)(CounterApp)