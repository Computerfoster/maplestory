import React,{Component} from 'react'
// 若使用class关键字定义类(有状态组件)，必须让其继承React.Component类
// class声明的组件变量props也只是可读的，不可以重新赋值
class Com2 extends React.Component{
    // 组件内部必须有render函数，渲染当前结构的虚拟DOM结构，为实例的实例方法
    // 重写自己的构造函数
    constructor(){
        // 必须先调用父类的构造函数super()
        super()
        // this.state={}约等于Vue中的data(){return {}}，该state是可读可写的
        this.state={
            message:'大家好，COm2的私有属性'
        }
    }

    render(){
        // render中必须返回合法的JSX虚拟DOM结构
        // 若需要使用到外部传进的props值，不需要接收，直接使用this.props来访问
        return <div>
                <h1>{this.props.name}</h1>
                <h1>{this.props.age}</h1>
                <h1>{this.state.message}</h1>
            </div>
    }
}
export default Com2

// 两种创建组建的方式区别：
//  class关键字创建的组件有自己的私有数据（即state）
//  function创建的组件没有私有数据及生命周期函数（vue中每个组件都有自己私有数据及生命周期函数）
// props都是外界传过来的、只可读不可写，state/data都是组件私有的、可读可写