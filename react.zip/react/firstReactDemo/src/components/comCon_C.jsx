import Cb from '@/components/comCon_B'
import React from 'react'

const list=[
    {
        text:'11111'
    },
    {
        text:'22222'
    },
    {
        text:'33333'
    },
    {
        text:'44444'
    },
    {
        text:'55555'
    }
]

export default class Cc extends React.Component{
    render(){
        return(
            <div>
                <Cb list={list}></Cb>
            </div>
        )
    }
}