import React, { Component } from 'react';
import './style.css'

class OrderItem extends Component {
    constructor(props){
        super(props)
        this.state={
            editing:false,
            stars:this.props.stars||0,
            comment:this.props.comment||"好好吃"
        }
        
    }
    render() {
        const {shop,product,price,picture,ifCommand}=this.props.data
        return (
            <div className="orderItem">
                <div className="orderItem__picContainer">
                    <img className='orderItem__pic' src={picture}></img>
                </div>
                <div className="orderItem__content">
                    <div className="orderItem__product">{product}</div>
                    <div className="orderItem__shop">{shop}</div>
                    <div className="orderItem__detail">
                        <div className="orderItem__price">{price}</div>
                        <div>
                            {
                                ifCommand ? (
                                    <button className="orderItem__btn orderItem__btn--grey" onClick={()=>{this.handleOpenComment()}}>查看评价内容</button>
                                ):  (
                                    <button className="orderItem__btn orderItem__btn--red" onClick={()=>{this.handleOpenComment()}}>评价</button>
                                )    
                            }

                        </div>
                    </div>
                </div>
                {this.state.editing?this.renderEditArea():null}
            </div>
        );
    }
    renderEditArea(){
        return(
            <div className='orderItem__commentContainer'>
                <textarea onChange={(e)=>{this.handleCommentChange(e)}} value={this.state.comment} className="orderItem__comment"></textarea>
                {this.renderStar()}
                <button className="orderItem__btn orderItem__btn--red" onClick={()=>{this.submitCommit()}}>提交</button>&nbsp;&nbsp;
                <button className="orderItem__btn orderItem__btn--grey" onClick={()=>{this.cancelCommit()}}>取消</button>
            </div>
        )
    }
    renderStar(){
        const {stars}=this.state
        return(
            <div className="starPoiner">
                {
                    [1,2,3,4,5].map((item,index)=>{
                        const lightClass=stars>item?"orderItem__star--light":""
                        return (
                            <span key={index} className={"orderItem__star "+lightClass} onClick={this.handleClickStar.bind(this,item)}>★</span>
                        )
                    })
                }
            </div>
        )
    }
    handleOpenComment=()=>{
        this.setState({
            editing:true
        })
    }
    handleCommentChange=(e)=>{
        this.setState({
            comment:e.target.value
        })
    }
    handleClickStar=(stars)=>{
        this.setState({
            stars:stars
        })
    }
    cancelCommit=()=>{
        this.setState({
            editing:false,
            comment:this.props.data.comment||'',
            stars:this.props.data.stars||0
        })
    }
    submitCommit=()=>{
        const {id}=this.props.data
        const {comment,stars}=this.state
        this.setState({
            editing:false
        })
        this.props.submitCommit(id,comment,stars)
    }
}

export default OrderItem;