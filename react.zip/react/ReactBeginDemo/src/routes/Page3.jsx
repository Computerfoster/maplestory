import React, { Component } from 'react';
import request from '../utils/request'
import {Table,Card,Button,Icon} from 'antd'

class Page3 extends Component {
    constructor(){
        super()
        this.state={
            data:{}
        }
    }
    render() {
        const columns=[
            {
                title:'ID',
                dataIndex:'id'
            },
            {
                title:'EMAIL',
                dataIndex:'email'
            },
            {
                title:'NAME',
                dataIndex:'name'
            }
        ]
        const pa={
            pageSize:4
        }
        return (
            <div style={{ width: '90%'}}>
                <Card title="This Is Page3" extra={<Button type="primary" size="small" onClick={()=>{this.click()}}>Search</Button>} style={{ width: '100%' ,margin:'8px auto 8px auto'}}>
                    {/* <input type='button' onClick={()=>{this.click()}}></input> */}
                    <Table columns={columns} dataSource={this.state.data.data} pagination={pa}>

                    </Table>
                </Card> 
            </div>
        );
    }
    click=()=>{
        request('api/page3').then(data=>{
            this.setState({
                data:data
            })
        })
    }
}

export default Page3;