import React, { Component } from 'react';
import TodoList from '../todo_list'
import TodoInput from '../todo_input'

class index extends Component {
    constructor(){
        super()
        this.state={
            todos:[]
        }
    }
    handleAdd=(value)=>{
        const id=new Date()
        this.setState({
            todos:this.state.todos.concat({
                id:id,
                text:value
            })
        })
    }
    handleDel=(id)=>{
        const data=this.state.todos
        this.setState({
            todos:data.filter((item,index)=>{
                if(item.id!=id){
                    return item
                }
            })
        })
    }
    render() {
        return (
            <div>
                <TodoInput handleAdd={(value)=>{this.handleAdd(value)}}></TodoInput>
                <TodoList todos={this.state.todos} handleDel={(id)=>{this.handleDel(id)}}></TodoList>
            </div>
        );
    }
}

export default index;