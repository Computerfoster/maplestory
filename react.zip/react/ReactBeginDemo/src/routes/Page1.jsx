import React, { Component } from 'react';
import request from '../utils/request'
import {Table,Card,Button,Icon} from 'antd'

class Page1 extends Component {
    constructor(){
        super()
        this.state={
            data:{}
        }
    }
    render() {
        const columns=[
            {
                title:'ID',
                dataIndex:'id'
            },
            {
                title:'TITLE',
                dataIndex:'title'
            },
            {
                title:'DES',
                dataIndex:'description'
            }
        ]
        return (
            <div>
                <Card title="This Is Page1" extra={<Button type="primary" size="small" onClick={()=>{this.click()}}>Search</Button>} style={{ width: 700 ,margin:'8px auto 8px auto'}}>
                    {/* <input type='button' onClick={()=>{this.click()}}></input> */}
                    <Table columns={columns} dataSource={this.state.data.data}>

                    </Table>
                </Card>    
            </div>
        );
    }
    click=()=>{
        request('api/page1').then(data=>{
            this.setState({
                data:data
            })
        })
    }
}

export default Page1;