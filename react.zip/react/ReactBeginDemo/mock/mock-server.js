// 导入Koa类
const Koa = require('koa');
// 创建一个Koa实例，供使用
const app = new Koa();
// 导入koa-router包，注意它返回的是一个函数
const router = require('koa-router')();
// 导入bodyParser包，用来解析元原始request请求
const bodyParser = require('koa-bodyparser');
const mock = require('./mock')

// 添加bodyParser中间件,将解析后的参数放在ctx.request.body中（由于middleware的注册顺序很重要，bodyParser要在router之前注册）
app.use(bodyParser())

// 添加，注册router的中间件
app.use(mock.routes())

// 1.对于任何请求，app将调用该异步函数处理请求
// 2.参数ctx封装了request和response，可以通过该参数访问request和response
// 3.方法await next()用来处理下一个异步函数，然后可以设置response和content-Type的内容，即一个中间件
// router.get('/list', async(ctx, next) => {
//   ctx.body = home
//   await next()
// })

// error-handling
app.on('error', (err, ctx) => {
    console.error('server error', err, ctx)
});

app.listen(3005);  //这里的端口要和webpack里devServer的端口对应
console.log('app started at port 3005')
