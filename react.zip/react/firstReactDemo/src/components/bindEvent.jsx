import React from 'react'

export default class Binde extends React.Component{
    constructor(){
        super()
        this.state={

        }
    }
    render(){
        return <h1>binde
            {/* react有一套自己的时间绑定机制，即驼峰式 */}
            {/* 为react绑定react事件时，必须使用onClick={function} */}
            {/* 注意myclickFunction和myclickFunction()的区别：前者表示引用，后者使用()表示执行该函数，并将该函数的返回值放置于此 */}
            {/* onClick={this.myclickFunction} 常规写法 */}
            {/* 以下使用箭头函数为react中最常用的写法 */}
            <button onClick={()=>{this.myclickFunction('ooo')}}>点击我</button>
        </h1>
    }
    //和render方法都是属于实例方法，即可以与render平级 
    // myclickFunction(){
    //     alert('ddd')
    // }
    // 知识点：箭头函数的this指向（指向当前上下文的对象，而不是调用者），setTimeOut的调用者（window），函数的调用和引用的区别
    // 事件的处理函数要定义为一个箭头函数，然后赋值给函数名
    myclickFunction=(args)=>{
        alert('this is'+args)
    }
}