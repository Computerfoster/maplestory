import React from 'react'
import {connect} from 'react-redux'
import {addTodo,todocount} from '../redux/actions'

// dispatch是由父组件中provider提供store供它的子组件使用的，在这里使用es6的析构函数得到其中的一个对象dispatch，拿来使用
// 源自于store.dispatch()
const AddTodo=({dispatch})=>{
    let input
    return (
        <div>
            <form onSubmit={e=>{
                e.preventDefault()
                if(!input.value.trim()){
                    return
                }
                // 在这里使用dispatch向外触发action（这个action是个对象，可以从外部引入该action对象）
                dispatch(addTodo(input.value))
                input.value=''
            }}>
                <input ref={node=>input=node}></input>
                <button type='submit'>Add todo</button>{' '}
                {/* 这个action是出于第二个reducer下的actions，但是他的type是在第一个reducer里有相同的type，结果是会同样触发 */}
                <button onClick={()=>{dispatch(todocount)}}>Add count</button>
            </form>
        </div>
    )
}
// 若connect中没有参数时，只注入dispatch，而不监听state
export default connect()(AddTodo)