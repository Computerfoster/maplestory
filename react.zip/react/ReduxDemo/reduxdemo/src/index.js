import React from 'react';
import ReactDOM from 'react-dom';
import App from './App';
import AppRedux1 from './App_redux_1';
import MapCom from './components/MapComponent'
// import * as serviceWorker from './serviceWorker';

ReactDOM.render(<MapCom />, document.getElementById('root'));
// ReactDOM.render(<App />, document.getElementById('root'));
// ReactDOM.render(<AppRedux1 />, document.getElementById('root'));

// serviceWorker.unregister();
