import React from 'react' //创建组件，虚拟dom元素
import objCss from '../css/cmtItem.css'


export default function CmtItem(props){
    return <div className={objCss.itemStyle}>
        <div>
            <h4 className={objCss.userStyle}>评论人：{props.user}</h4>
            <p className={objCss.contentStyle}>评论内容：{props.content}</p>
        </div>
    </div>
}