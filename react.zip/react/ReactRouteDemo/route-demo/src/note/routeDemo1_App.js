import React from 'react';
import './css/App.css';
import Sc from './components/secondRoute'
import {BrowserRouter as Router,Route,Link,NavLink,Switch} from 'react-router-dom'

function App() {
  return (
    // 所有代码都包含在Router中，单个路由包含在Route中
    <Router>
        {/* 
            1.Router下面只能包含一个盒子标签，类似于div 
            2.Link代表一个超链接，必须有一个to参数
            3.Route代表了一个要显示的页面，path表示路径，component表示展示的组件
              <Route path='/demo' components={Demo}></Route>
            4.Switch是为了将React默认的包容性路由改为排他性路由；除了使用switch来达到精确匹配，也可以在每一个Route添加exact达到Switch的效果
              包容性路由：/food既能匹配到/也能匹配到/food
              排他性路由：/food只能匹配带/food
            5.Redirect是路由转化，即匹配到一个路由转化为另一个路由
        */}
        <div className='App'>
          {/* 
              1.link使用to参数来描述需要定位页面，它的值可以是字符串，也可以时loccation对象
               即包含pathname、search、hash和state属性，如果其为字符串，将会被转为location对象
              2.link组件最终会被转化为<a>，它的to、query和hash属性组合中渲染为href，虽然
               Link被渲染为超链接，但是在内部使用脚本实现了拦截浏览器的默认行为，然后调用了history.pushState()
              3.NavLink是Link的一个特殊版本，在Link的基础上会在已经匹配上的url元素添加参数，例如activeClassName、activeStyle之类的属性
           */}
          <Link style={{marginRight:'10px'}} to="/">Home</Link>
          <Link style={{marginRight:'10px'}} to="/article">article</Link>
          <Link style={{marginRight:'10px'}} to="/about">about</Link>
          <Link style={{marginRight:'10px'}} to="/outside">outside</Link>

          <Switch>
            <Route exact path="/" render={props=>(
              <React.Fragment>
                <h3>Home</h3>
                this is home page
              </React.Fragment>
            )}>
            </Route>
            
            <Route exact path="/article" render={props=>(
              <React.Fragment>
                <h3>article</h3>
                this is article page
              </React.Fragment>
            )}>
            </Route>

            <Route exact path="/about" render={props=>(
              <React.Fragment>
                <h3>about</h3>
                this is about page
              </React.Fragment>
            )}>
            </Route>
            
            <Route exact path="/outside" component={Sc}>
            </Route>
          </Switch>
        </div>
    </Router>
  );
}

export default App;
