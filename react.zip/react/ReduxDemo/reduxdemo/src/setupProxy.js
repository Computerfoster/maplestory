const proxy = require("http-proxy-middleware");

module.exports = function(app) {
    app.use(proxy("/sapi", {
        target: "http://127.0.0.1:3005/" , //配置你要请求的服务器地址
        changeOrigin: true,
        pathRewrite: {"^/sapi" : ""}
    }))
};