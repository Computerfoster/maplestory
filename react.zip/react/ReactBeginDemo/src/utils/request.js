// 引入whatwg-fetch的目的就是让低版本的浏览器版本也能使用fetch
import 'whatwg-fetch'

const codeMessage={
    200: '服务器成功返回请求的数据。',
    201: '新建或修改数据成功。',
    202: '一个请求已经进入后台排队（异步任务）。',
    204: '删除数据成功。',
    400: '发出的请求有错误，服务器没有进行新建或修改数据的操作。',
    401: '用户没有权限（令牌、用户名、密码错误）。',
    403: '用户得到授权，但是访问是被禁止的。',
    404: '发出的请求针对的是不存在的记录，服务器没有进行操作。',
    406: '请求的格式不可得。',
    410: '请求的资源被永久删除，且不会再得到的。',
    422: '当创建一个对象时，发生一个验证错误。',
    500: '服务器发生错误，请检查服务器。',
    502: '网关错误。',
    503: '服务不可用，服务器暂时过载或维护。',
    504: '网关超时。',
}

function checkStatus(response){
    // 判断response中的status，若为正常的code则直接返回response
    if(response.status>=200&&response.status<300){
        return response
    }
    // 否则错误的状态码得到错误原因对应的解释
    const errortext=codeMessage[response.status]||response.statusText
    // 设置error的name和response的值
    const error=new Error(errorText)
    error.name=response.status
    error.response=response
    // 抛出error异常
    throw error
}

// 对外暴漏一个函数接口，外面可以直接调用该函数实现fetch（即对外实现了对fetch的包装）
export default function request(url,options){
    const defaultOptions={
        credentials:'include',
    }
    // 组合成新fetch的options
    const newOptions={...defaultOptions,...options}
    // 若fetch请求的为POST或PUT请求，则在请求头中附加一些信息；否则直接进行fetch请求
    if(newOptions.method==='POST'||newOptions.method==='PUT'){
        if(!(newOptions.body instanceof FormData)){
            newOptions.headers={
                Accept:'application/json',
                'Content-Type':'applicatoin/json;charset=utf-8',
                ...newOptions.headers
            }
            newOptions.body=JSON.stringify(newOptions.body)
        }else{
            newOptions.header={
                Accept:'appliction/json',
                ...newOptions.headers
            }
        }
    }
    // 在设置完fetch请求的header后，开始发起fetch请求，得到响应数据并处理后返回数据值
    return fetch(url,newOptions)
        .then(checkStatus)
        .then(response=>{
            if(newOptions.method==='DELETE'||response.status===204){
                return response.text()
            }
            return response.json()
        })
        .catch(e=>{
            const status=e.name
            console.log(status)
        })
    
}