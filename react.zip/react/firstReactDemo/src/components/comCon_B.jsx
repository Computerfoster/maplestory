import Ca from '@/components/comCon_A'
import React from 'react'
import PropTypes from 'prop-types'

export default class Cb extends React.Component{
    // （必有）加上childcontexttype属性
    static childContextTypes={
        color:PropTypes.string
    }
    static propTypes={
        list:PropTypes.array
    }
    // （必有）加上该方法就可以，其他地方就可访问此context值
    getChildContext(){
        return {
            color:'#C0C0C0'
        }
    }
    render(){
        const list=this.props.list
        return (
            <div>
                <ul>
                    {
                        list.map((entry,index)=>
                            <Ca key={`list-${index}`} value={entry.text}></Ca>
                        )
                    }
                </ul>
            </div>
        )
    }
}