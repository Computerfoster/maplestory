import React, { Component } from 'react';

class index extends Component {
    constructor(props){
        super(props)
    }
    handleDel=(id)=>{
        this.props.handleDel(id)
    }
    render() {
        let todos=this.props.todos?this.props.todos:[]
        return (
            <div>
                {
                    <ul>
                        {
                            todos.map((item,index)=>{
                                return (
                                     <li key={index}>
                                     {item.text}
                                        <span onClick={()=>{this.handleDel(item.id)}}>  X   </span>
                                    </li>
                                )
                            })
                        }
                    </ul>
                }
            </div>
        );
    }
}

export default index;