import React from'react'
import AddTodo from './AddTodo'
import TodoList from './TodoList'
import SecCom from './Couter_redux'

const app=()=>(
    <div>
        <AddTodo />
        <TodoList />
        <SecCom />
    </div>
)

export default app