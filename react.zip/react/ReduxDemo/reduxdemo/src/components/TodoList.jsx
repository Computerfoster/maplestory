import React from 'react'
import {connect} from 'react-redux'
import {toggleTodo} from '../redux/actions'

const Todo=({onClick,completed,text})=>(
    <li
        onClick={onClick}
        style={{
            textDecoration:completed?'line-through':'none'
        }}
        > 
        {text}
    </li>
)
// 这里的todos和toggleTodo是使用connect方法，将store中的state和action都作为props传入到组件中，
// 这样组件就可以直接使用action而不用使用dispatch就可触发action，也可以直接使用store中的state
const TodoList=({todos,toggleTodo})=>(
    <ul>
        {/* 直接使用store中的todos */}
        {todos.map(todo=>(
            //                                         这里可以是dispatch（toggleTodo的简写）
            <Todo key={todo.id} {...todo} onClick={()=>toggleTodo(todo.id)}></Todo>
        ))}
    </ul>
)
// 将 store 中的数据作为 props 绑定到组件上。
const mapStateToProps=state=>({
    // 这么写是应为combineReducers将store的reducer分为若干个模块，使用其中一个模块时，要.上其名字，才能使用
    // 可以理解为state也被化为多个模块（因为combineReducers）
    todos:state.todos
})
// 将 store 中的action作为 props 绑定到组件上。
const mapDispatcherToProps=dispatch=>({
    toggleTodo:id=>dispatch(toggleTodo(id))
})

export default connect(mapStateToProps,mapDispatcherToProps)(TodoList)