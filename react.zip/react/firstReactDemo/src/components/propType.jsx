import React from 'react'
import PropTypes from 'prop-types'

export default function Chlid({name}){
    return <h1>hello,{name}</h1>
}
// props的验证；可以写在组件内部，也可以像下面这样写在外部
// propTypes是固定的，不可更改
Chlid.propTypes={
    name:PropTypes.string.isRequired
}