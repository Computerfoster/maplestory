export const addCount={
    type:'ADD_COUNT'
}
export const subCount={
    type:'SUB_COUNT'
}