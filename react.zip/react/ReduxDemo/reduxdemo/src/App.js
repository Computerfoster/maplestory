import React from 'react';
import './App.css';
import {createStore,applyMiddleware} from 'redux'
import {Provider} from 'react-redux'
import thunk from 'redux-thunk'
import TodoApp from './components/TodoApp.jsx'
import todoReducer from './redux/reducers.js'

const store=createStore(todoReducer,applyMiddleware(thunk))
console.log(store.dispatch)

class App extends React.Component {
  render() {
    return (
      <div className="App">
        <Provider store={store}>
          <TodoApp />
        </Provider>
      </div>
    );
  }
}

export default App;
