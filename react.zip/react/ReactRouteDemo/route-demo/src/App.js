import React from 'react';
import './css/App.css';
import Sc from './components/secondRoute'
import Header from './components/Header'
import OrderList from './components/OrderList'
// import {BrowserRouter as Router,Route,Link,NavLink,Switch} from 'react-router-dom'

function App() {
  return (
    <div className="App">
      <Header></Header>
      <OrderList></OrderList>
    </div>
  )
}

export default App;
