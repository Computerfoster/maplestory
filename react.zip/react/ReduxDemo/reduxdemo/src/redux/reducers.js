import {combineReducers} from 'redux'
import todos from './todos'
import countReducer from './reducer_Couter'

export default combineReducers({
    todos,
    countReducer,
})