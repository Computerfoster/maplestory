import React from 'react'
import '../css/Second.css'
import {BrowserRouter as Router,Route,Link,Redirect} from 'react-router-dom'

export default class Sc extends React.Component{
    render(){
        return(
            <Router>
                <div className="out">
                    <Link style={{marginRight:'10px'}} to="/son/">jack</Link>
                    <Link style={{marginRight:'10px'}} to="/son/son2">mick</Link>

                    <Redirect path="/" to="/son/"></Redirect>
                    <Route exact path="/son/" render={props=>(
                        <React.Fragment>
                            <h3>son1</h3>
                            this is my son1
                        </React.Fragment>
                    )}></Route>

                    <Route exact path="/son/son2" render={props=>(
                        <React.Fragment>
                            <h3>son2</h3>
                            this is my son2
                        </React.Fragment>
                    )}></Route>
                </div>
            </Router>
        )
    }
}