import React from 'react'

export default class BindState extends React.Component{
    constructor(){
        super()
        this.state={
            msg:'msg',
            name:'jack',
            age:12,
            like:'lol'
        }
    }
    render(){
        return <div>
            <button onClick={()=>{this.show()}}>ooo</button>
            <h3>{this.state.msg}</h3>
            {/* 若只为文本框中的value绑定到state中，但是未提供onChange事件，那么得到的文本框得到的是一个只读的文本框 */}
            <input type="text" style={{width:"60%"}} value={this.state.msg} onChange={(e)=>{this.txtChange(e)}} ref='txt'></input>
        </div>
    }
    show=(r)=>{
        // 1.若为state中的数据重新赋值时，不要使用this.state直接赋值；应调用react的setState()来修改
        // 2.参数为一个对象，key值为要修改的属性名，value值为要修改的值
        // 3.在setState中只会把对应的属性值更新，其他的属性不会被修改和覆盖
        // 4.注意：setState方法为异步方法；若要得到最新的state值，需要写为：this.setState({},callback)
        this.setState({msg:'NEW MSG'})
    }
    txtChange=(e)=>{
        // 获取文本框中的值:1.通过事件参数e 
        // 2.通过ref。即this.refs.txt
        console.log(e.target.value)
        // 手动调用setState
        const newMsg=e.target.value
        this.setState({
            msg:newMsg
        })
    }
}