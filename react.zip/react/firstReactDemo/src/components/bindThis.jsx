import React, { Component } from 'react';

class BindThis extends Component {
    constructor(){
        super()
        this.state={
            age:999
        }
        // 解决方法一：在constructor用bind绑定this
        this.handleClick=this.handleClick.bind(this)
    }
    // 若使用这种方法定义函数，在点击按钮后得不到this
    // handleClick(){
    //     console.log('click!!')
    //     console.log(this.state.age)
    //     console.log(this)
    // }
    // 解决方法二：使用箭头函数的方法定义函数
    handleClick=()=>{
        console.log('click!!')
        console.log(this.state.age)
        console.log(this)
    }
    render() {
        return (
            <div>
                {/* 解决方法三：使用调用时使用箭头函数 */}
                <button onClick={()=>{this.handleClick()}}>DDDD</button>
            </div>
        );
    }
}

export default BindThis;