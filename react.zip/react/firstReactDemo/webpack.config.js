// 由于webpack是基于nodejs构建的，所以支持所有nodeAPI语法（chrome浏览器支持node就支持）
// webpack：默认只能处理js文件，其他文件需要第三方模块

const path=require('path')
const HtmlWebpackPlugin=require('html-webpack-plugin')

const htmlpp=new HtmlWebpackPlugin({
    template:path.join(__dirname,'./src/index.html'),
    filename:'index.html'
})

module.exports={
    // mode为必选项
    mode:'development',
    plugins:[
        htmlpp
    ],
    module:{// 所有第三方模块使用规则
        rules:[
            {
                test:/\.js|jsx$/,
                // 需要babel的配置文件，手动添加
                use:'babel-loader',
                // 排除项（使用Babel-loader时）
                exclude:/node_modules/
            },
            {
                test:/\.css$/,
                // 可以在css-loader后面追加参数，例如加上modules，为css样式表追加模块化
                use:['style-loader','css-loader?modules']
            }
        ]
    },
    resolve:{ //自动补全文件后缀名
        extensions:['.js','.jsx','.json'],
        alias:{ // 配置@符号
            '@':path.join(__dirname,'./src')
        }
    },
    externals:{
        'BMap':'BMap',
        },
}