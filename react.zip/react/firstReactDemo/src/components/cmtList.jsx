import React from 'react'
import CmtItem from './cmtItem'
// 这种方式导入的样式表是全局生效的
// css模块化只对类选择器和id选择器生效
import cssObj from '../css/cmtList.css'
console.log(cssObj)

export default class Cmt extends React.Component{
    constructor(){
        super()
        this.state={
            list:[
                {id:1,user:'张三',content:'11111'},
                {id:2,user:'张三',content:'22222'},
                {id:3,user:'张三',content:'33333'},
                {id:4,user:'张三',content:'44444'},
                {id:5,user:'张三',content:'55555'},
            ],
            test:66
        }
    }
    render(){
        return <div>
            <h1 className={cssObj.title}>这是评论列表组件</h1>
            {this.state.list.map(item=>
                <CmtItem {...item} key={item.id}></CmtItem>
            )}
            </div>
    }
}

