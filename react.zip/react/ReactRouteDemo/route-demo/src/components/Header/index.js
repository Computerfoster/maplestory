import React, { Component } from 'react';
import './style.css'

class Header extends Component {
    render() {
        return (
            <div className="header">
                大众电瓶
            </div>
        );
    }
}

export default Header;