import  React,{Component} from 'react';
import BMap  from 'BMap';

 class AddressUi extends Component{ 
    componentDidMount(){
        var map = new BMap.Map("address"); // 创建Map实例
        // map.centerAndZoom(new BMap.Point(114.02919,30.58203), 11); // 初始化地图,设置中心点坐标和缩放程度
        map.centerAndZoom('十堰', 15);// 可以直接填写城市对应的名称
        map.addControl(new BMap.MapTypeControl()); //添加地图类型控件
        map.setCurrentCity("武汉"); // 设置地图显示的城市 此项是必须设置的
        map.addControl(new BMap.NavigationControl());//缩放平移控件
        map.addControl(new BMap.ScaleControl());    //比例尺
        map.addControl(new BMap.OverviewMapControl());//缩略图
        map.addControl(new BMap.MapTypeControl()); //地图类型
        map.enableScrollWheelZoom();// 是否可以通过滑轮来放缩地图
    }

    render() {
      return(
              <div id="address" style={{ position: "absolute", top: 0, left: 0, width: '100vw', height: '100vh' }}>
              </div>
      )
  }
}
export default AddressUi
