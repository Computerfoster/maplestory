import React from 'react'
import PropTypes from 'prop-types'

export default class Cson extends React.Component{
    static propTypes={
        hideCom:PropTypes.func.isRequired
    }
    render(){
        return (<div>
            this is son
            <button onClick={this.say}>点我隐藏son</button>
        </div>)
    }
    say=()=>{
        this.props.hideCom('haha')
    }
}