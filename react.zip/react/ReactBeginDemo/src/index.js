import ReactDOM from 'react-dom'
import React from 'react'
import Router from './router'
import Mapdemo from './components/Mapdemo'

ReactDOM.render(
    // <Router />,
    <Mapdemo></Mapdemo>,
    document.getElementById('root')
)