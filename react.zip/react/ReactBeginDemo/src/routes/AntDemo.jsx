import React, { Component } from 'react';
import {Menu,Icon} from 'antd'
import {Link} from 'react-router-dom'

class AntDemo extends Component {
    render() {
        return (
            <div>
                <Menu mode="horizontal">
                    <Menu.Item key="android">
                        <Icon type="android" />
                        <Link to='/dsfsdf'></Link>
                        android
                    </Menu.Item>
                    <Menu.Item key="apple">
                        <Link to='/ssssss'><Icon type="apple"></Icon>apple</Link>
                    </Menu.Item>
                    <Menu.Item key="windows">
                        <Icon type="windows" />
                        windows
                    </Menu.Item>
                    <Menu.Item key="github">
                        <Icon type="github" />
                        github
                    </Menu.Item>
                </Menu>
            </div>
        );
    }
}

export default AntDemo;