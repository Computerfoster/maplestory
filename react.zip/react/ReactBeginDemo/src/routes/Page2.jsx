import React, { Component } from 'react';
import request from '../utils/request'

class Page2 extends Component {
    constructor(){
        super()
        this.state={
            data:{}
        }
    }
    render() {
        return (
            <div>
                <h1>hello Page2</h1>
                <input type='button' value="获取mock" onClick={()=>{this.click()}}></input>
                <div style={{width:300}}>
                    <p>Page2 的mock内为：{JSON.stringify(this.state.data)}</p>
                </div>
            </div>
        );
    }
    click=()=>{
        request('api/page2').then(data=>{
            this.setState({
                data:data
            })
        })
    }
}

export default Page2;