import React, { Component } from 'react';
import {Route,Switch,Redirect,Link} from 'react-router-dom'

import Page1 from './Page1.jsx'
import Page2 from './Page2.jsx'
import Page3 from './Page3.jsx'
import AntDemo from './AntDemo.jsx'
import {Menu,Icon} from 'antd'

class Home extends Component {
    render() {
        return (
            <div>
                <Menu mode="horizontal" style={styles.container} theme='dark'>
                    <Menu.Item key="android">
                        <Link to='/page1'><Icon type="android"></Icon>page1</Link>
                    </Menu.Item>
                    <Menu.Item key="apple">
                        <Link to='/page2'><Icon type="apple"></Icon>page2</Link>
                    </Menu.Item>
                    <Menu.Item key="windows">
                        <Link to='/page3'><Icon type="windows"></Icon>page3</Link>
                    </Menu.Item>
                    <Menu.Item key="github">
                        <Link to='/page4'><Icon type="github"></Icon>page4</Link>
                    </Menu.Item>
                </Menu>
                {/* <div style={styles.container}>
                    <Link to="/page1" style={styles.link}>Page1</Link>
                    <Link to="/page2" style={styles.link}>Page2</Link>
                    <Link to="/page3" style={styles.link}>Page3</Link>
                    <Link to="/antDemo" style={styles.link}>AntDemo</Link>
                </div> */}
                <div style={styles.content}>
                    <Switch>
                        <Route  path="/page1" component={Page1}></Route>
                        <Route  path="/page2" component={Page2}></Route>
                        <Route  path="/page3" component={Page3}></Route>
                        <Route  path="/antDemo" component={AntDemo}></Route>
                        <Redirect exact from="/" to="/page1"></Redirect>
                    </Switch>
                </div>
            </div>
        );
    }
}

const styles={
    container:{
        display:'flex',
        justifyContent:'space-around',
        border:'1px solid',
        margin:'0px auto 8px auto',
        height:'50px',
        width:'50%'
    },
    content:{
        margin:'0px auto 8px auto',
        border:'1px solid',
        width:'70%',
        display:'flex',
        justifyContent:'center',
        backgroundColor:'#0099FF'
    },
    link:{
        marginRight:10
    }
}

export default Home;