import React from 'react'
import Cson from '@/components/comConnect_son'

export default class Cfather extends React.Component{
    constructor(...args){
        super(...args)
        this.state={
            isShowList3:false
        }
    }
    showComponent=()=>{
        this.setState({
            isShowList3:true
        })
    }
    hideComponent=(val)=>{
        this.setState({
            isShowList3:false
        },)
        console.log(val)
    }
    render(){
        return (
            <div>
                <button onClick={()=>{this.showComponent()}}>显示son</button>
                {
                    this.state.isShowList3 ?
                    <Cson hideCom={(val)=>{this.hideComponent(val)}}></Cson>
                    :
                    null
                }
            </div>
        )
    }
}