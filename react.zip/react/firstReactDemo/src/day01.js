import React from 'react' //创建组件，虚拟dom元素
import ReactDom from 'react-dom'//展示组件及虚拟dom
// 1.使用React创建虚拟dom元素
// 参数一：创建的元素的类型，字符串表示元素的名称
// 参数二：是一个对象，表示该dom元素的属性
// 参数三：子节点
// 参数n：子节点
// ex：<div id='myh1' title='this is my'>uiuiuiuiuiu</div>
// const ele1=React.createElement('h1',{id:'myh1',title:'this is a h1'},'uiuiuiuiuiu')
// const ele2=React.createElement('div',null,'this is a div',ele1)

// 由于在js文件中，不能写html类型的标签；但是可以通过使用babel来转换html内容
// 这种在js中，混合写入类似于html的语法，叫做JSX语法 
// JSX语法的本质，还是在运行时被转化为React.createElement()形式
const arrstr=['老大','老二','老三','老四','老五']
// const result=[]

// arrstr.forEach(item=>{
//     let rr=<h1>{item}</h1>
//     result.push(rr)
// })
const mydiv=<div key={item}>
{arrstr.map(item=><h3>{item}</h3>)}
</div>

// 2.使用ReactDom渲染dom元素
// 参数一：需要渲染的元素
// 参数二：指定页面上的一个容器
ReactDom.render(mydiv,document.getElementById('app'))