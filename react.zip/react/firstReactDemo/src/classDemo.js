class Animal{
    // 实例属性
    constructor(name,age){
        this.name=name,
        this.age=age
    }
    // 静态属性，通过static修饰，只能通过类名访问
    static like='aaa'
    // 实例方法
    say(){
        console.log('sssss')
    }
    // 静态方法
    static show(){
        console.log('wwwww')
    }
}

const a1=new Animal('sss',34)
console.log(a1.like)
console.log(Animal.like)
console.log(a1.say())
console.log(Animal.show())