import React from 'react'
import {createStore,applyMiddleware} from 'redux'
import {Provider} from 'react-redux'
import CouterRedux from './components/Couter_redux'
import reducerCouter from './redux/reducer_Couter'
import thunk from 'redux-thunk'

const store=createStore(reducerCouter,applyMiddleware(thunk))
// console.log(store.getState())

class AppRedux1 extends React.Component {
    render() {
        return (
            <div style={{margin:'50px auto 50px auto'}}>
                <Provider store={store}>
                    <CouterRedux /> 
                </Provider>
            </div>
        );
    }
}

export default AppRedux1;